import re
import os
import sys
import easygui

# path_file = easygui.fileopenbox()
path_file = r"C:\Projects\PMAs\PMA-15\01_Working\01_INPUT\01_Source_Code\V2\PMA-15-C-RE\PF\MDL\FS\fs_fs_can.c"

f = open(path_file)
all_file = f.read()
# list_file = all_file.split("\n")
# f.seek(0) #đưa con trỏ về lại đầu file
f.seek(0)
list_file = list(f) # chuyển file về thành list để xử lý
count_line = len(list_file)
f.close()

#### ^{[\s\S]*?^} regex bắt từ đầu func tới cuối func

""" bắt nguyên 1 func từ comment tới hết func
######### \/\*[^;}]*?\*\/\s+(static\s)?.*\s+FsFsCan_Check_CanTmOut_EcmPropFr24\(.*\)\s+^{[\s\S]+^}\s
"""
name_func = "FsFsCan_Check_CanTmOut_EcmPropFr24"
pattern_start2func = "[\s\S]+" + name_func + "\(.*\)\s+{"
pattern_func = "\/\*[^;}]*?\*\/\s+(static\s)?.*\s+" + name_func + "\(.*\)\s+{"

all = re.search(pattern_start2func,all_file).group()
only = re.search(pattern_func,all_file).group() + "\n"

# print(len(all.split("\n")))
for data in range(len(all.split("\n")),len(list_file)):
    if len(list_file[data]) > 0 and list_file[data][0] == "}":
        only += list_file[data]
        break
    else:
        only += list_file[data] 

print(only)








































































