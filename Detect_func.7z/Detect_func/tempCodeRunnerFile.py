file = open("xxxx.c","w+")
file.write(only.group())
file.close()