# import re
# import os
# import sys
# import easygui


# # https://viblo.asia/p/regular-expression-reference-ZDEeLDNneJb
# # path_file = easygui.fileopenbox()
# path_file = r"C:\Projects\PMAs\PMA-15\01_Working\01_INPUT\01_Source_Code\V2\PMA-15-C-RE\PF\MDL\FS\fs_fs_can.c"
# f = open(path_file)
# all_file = f.read()
# f.close()

# """ bắt nguyên 1 func từ comment tới hết func
# ######### \/\*[^;}]*?\*\/\s+(static\s)?.*\s+FsFsCan_Check_CanTmOut_EcmPropFr24\(.*\)\s+^{[\s\S]+^}\s
# """
# name_func = "FsFsCan_Check_CanTmOut_EcmPropFr24"

# pattern_func = "\/\*[^;}]*?\*\/\s+(static\s)?.*\s+" + name_func + "\(.*\)\s+{"
# # pattern_func = "\/\*[^;}]*?\*\/\s+(static\s)?.*\s+FsFsCan_Check_CanTmOut_EcmPropFr24\(.*\)\s+^{[\s\S]+^}\s+"
# only = re.match(pattern_func,all_file)

# print(only)
# # print(all_file)

import re
import os
import sys
import easygui

# path_file = easygui.fileopenbox()
path_file = r"C:\Projects\PMAs\PMA-15\01_Working\01_INPUT\01_Source_Code\V2\PMA-15-C-RE\PF\MDL\FS\fs_fs_can.c"

f = open(path_file)
all_file = f.read()
f.close()

#### ^{[\s\S]*?^} regex bắt từ đầu func tới cuối func

""" bắt nguyên 1 func từ comment tới hết func
######### \/\*[^;}]*?\*\/\s+(static\s)?.*\s+FsFsCan_Check_CanTmOut_EcmPropFr24\(.*\)\s+^{[\s\S]+^}\s
"""
name_func = "FsFsCan_Check_CanTmOut_EcmPropFr24"
pattern_func = "\/\*[^;}]*?\*\/\s+(static\s)?.*\s+" + name_func + "\(.*\)\s+{[\s\S]*?\n}"
only = re.search(pattern_func,all_file)


file = open("xxxx.c","w+")
file.write(only.group())
file.close()












































































































































